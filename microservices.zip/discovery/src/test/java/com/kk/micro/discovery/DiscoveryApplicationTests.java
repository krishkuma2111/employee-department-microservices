package com.kk.micro.discovery;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Disabled
@SpringBootTest
class DiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
