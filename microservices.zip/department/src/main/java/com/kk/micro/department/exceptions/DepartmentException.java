package com.kk.micro.department.exceptions;

public class DepartmentException extends RuntimeException{
    public DepartmentException(String msg){ super(msg); }
}