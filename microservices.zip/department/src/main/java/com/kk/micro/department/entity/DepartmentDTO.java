package com.kk.micro.department.entity;

public record DepartmentDTO(Long id, Long departmentId, String name){}
