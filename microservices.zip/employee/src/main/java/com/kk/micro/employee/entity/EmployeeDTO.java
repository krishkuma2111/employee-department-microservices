package com.kk.micro.employee.entity;

public record EmployeeDTO(String name, double salary, String deptName){   
}
