package com.kk.micro.employee.entity;

public record DepartmentDTO(Long id, Long departmentId, String name){}
