package com.kk.micro.employee.exceptions;

public class EmployeeException extends RuntimeException{
    public EmployeeException(String msg){ super(msg); }
}